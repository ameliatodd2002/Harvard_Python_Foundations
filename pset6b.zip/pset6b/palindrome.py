def is_palindrome(a_string):
    b_string = a_string.lower()
    if len(b_string) <= 1:
        return True
    else:
        return (b_string[0] == b_string[-1]) and (is_palindrome(b_string[1:-1]))

print(is_palindrome('kayaK'))