import sys

def encrypt(keyword, text):
    keyword = keyword.upper()
    encrypted_text = []
    keyword_index = 0

    for char in text:
        char = char.upper()
        if char == " ":
            encrypted_text.append(char)
        else:
            keyword_shift = ord(keyword[keyword_index % len(keyword)]) - ord('A')
            encrypted_char = chr((ord(char) - ord('A') + keyword_shift) % 26 + ord('A'))
            encrypted_text.append(encrypted_char)
            keyword_index += 1


    return ''.join(encrypted_text)

def decrypt(keyword, text):
    keyword = keyword.upper()
    decrypted_text = []
    keyword_index = 0

    for char in text:
        char = char.upper()
        if char == " ":
            decrypted_text.append(char)
        else:
            keyword_shift = -(ord(keyword[keyword_index % len(keyword)]) - ord('A'))
            decrypted_char = chr((ord(char) - ord('A') + keyword_shift) % 26 + ord('A'))
            decrypted_text.append(decrypted_char)
            keyword_index += 1

    return ''.join(decrypted_text)

def main():
    if len(sys.argv) < 4:
        print("Usage: python cipher.py <keyword> <input_file> <output_file>")
        return

    keyword = sys.argv[1]
    input_file = sys.argv[2]
    encrypt_file = sys.argv[3]


    if len(sys.argv) == 4:
        with open(input_file, "r") as input_file:
            plaintext_input = input_file.read().strip()
        encrypted_text = encrypt(keyword, plaintext_input)
        with open(encrypt_file, "w") as output_file:
            output_file.write(encrypted_text)
        print("Encryption complete.")
    elif len(sys.argv) == 5 and sys.argv[2] == '-d':
        output_file = sys.argv[4]
        with open(encrypt_file, "r") as input_file:
            plaintext_input = input_file.read().strip()
        decrypted_text = decrypt(keyword, plaintext_input)
        with open(output_file, "w") as output_file:
            output_file.write(decrypted_text)
        print("Decryption complete.")
    else:
        print("Usage: python cipher.py <keyword> <input_file> <output_file> [-d]")

if __name__ == "__main__":
    main()

#python cipher.py FOOBAR input.txt encrypt.txt
#python cipher.py FOOBAR -d encrypt.txt output.txt
