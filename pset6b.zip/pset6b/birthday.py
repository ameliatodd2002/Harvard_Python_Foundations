import sys
import random

def birthday(simulation_num, student_num):
    if len(sys.argv) < 3:
        print("Error. Correct usage: birthday.py simulation_num student_num")
    else:
        sim_match = 0
        for i in range(simulation_num):
            birthday_list = []
            match = 0
            for i in range(student_num):
                birthday = []
                birth_month = (random.randint(1, 12))
                if birth_month in [1, 3, 5, 7, 8, 10, 12]:
                    birthday = [birth_month, random.randint(1, 31)]
                elif birth_month in [4, 6, 9, 11]:
                    birthday = [birth_month, random.randint(1, 30)]
                elif birth_month == 2:
                    birthday = [birth_month, random.randint(1, 29)]

                if birthday in birthday_list:
                    match += 1
                birthday_list.append(birthday)

            if match >= 1:
                sim_match += 1
    return sim_match

def main():
    simulation_num = int(sys.argv[1])
    student_num = int(sys.argv[2])
    sim_match = birthday(simulation_num, student_num)
    print(f"After {sys.argv[1]} simulations\nwith {sys.argv[2]} students\nthere were {sim_match} simulations with at least one match")

if __name__ == "__main__":
    main()

#python birthday.py 1 
