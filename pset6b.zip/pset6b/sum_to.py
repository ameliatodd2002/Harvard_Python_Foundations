def sum_to(n):
    if n < 0:
        return "Error. Value of n should be greater than or equal to 0"
    if n == 0:
        return 0.0
    else:
        return 1 / n + sum_to(n - 1)

def main():
    print(sum_to(2))

if __name__ == "__main__":
    main()