import sys

sum_of_args = sum(int(argument) for argument in sys.argv[1:])
print(f"The sum of the args is: {sum_of_args}")

