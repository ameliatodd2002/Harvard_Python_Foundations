def digit_sum(n):
    if n < 10:
        return n
    else:
        return (n % 10) + digit_sum(n // 10)

def main():
    print(digit_sum(3456))

if __name__ == "__main__":
    main()