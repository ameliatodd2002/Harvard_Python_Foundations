import random
import sys

def roulette():
    output = open(sys.argv[1], "w")
    n = int(sys.argv[2])

    if len(sys.argv) != 3:
        print("Error. Correct usage: roulette.py output_file_name n")
    else:
        for x in range (n):
            random_int = str(random.randint(0, 37))
            output.write((random_int) + "\n")

    output.close()

roulette()